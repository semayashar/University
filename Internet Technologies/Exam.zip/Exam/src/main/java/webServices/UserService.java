package webServices;

import java.util.List;

import entities.User;
import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import managed_entities.searchUser;

@Path("users")
public class UserService
{
	@Inject
    private searchUser service;
	
	@GET
    @Path("/all")
    @Produces(MediaType.APPLICATION_JSON)
    public List<User> allUsers() {
        return service.getAllUsers();
    }

}
