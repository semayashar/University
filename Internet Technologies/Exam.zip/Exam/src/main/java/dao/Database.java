package dao;

import entities.User;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class Database {

    @PersistenceContext(unitName = "JPADefaultDataBaseConnection")
    private EntityManager em;

    public void addUser(User user) {
        em.persist(user);
    }

    public List<User> returnUsers() {
        return em.createQuery("SELECT u FROM User u", User.class).getResultList();
    }

    public boolean found(String name, String password) {
    	List <User> allUsers = returnUsers();
    	
    	if (allUsers != null) {
            for (User user : allUsers) {
                if (user.getUsername().equals(name) && user.getPassword().equals(password)) {
                    return true;
                }
            }
        }
    	
		return false;
    }

}
