package managed_entities;

import java.util.ArrayList;
import java.util.List;

import dao.Database;
import entities.User;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.RequestScoped;

import jakarta.inject.Named;

@Named
@RequestScoped
public class searchUser {
    private String searchUsername;
    private List<User> searchResults;
    private List<User> allUsers;
    
    @EJB
    Database db;
    
    @PostConstruct
    public void init() {
        allUsers = db.returnUsers();
    }

    public List<User> getAllUsers() {
        return allUsers;
    }
    
    public String getSearchUsername() {
        return searchUsername;
    }

    public void setSearchUsername(String searchName) {
        this.searchUsername = searchName;
    }

    public List<User> getSearchResults() {
        return searchResults;
    }

    public void setSearchResults(List<User> searchResults) {
        this.searchResults = searchResults;
    }
    
    public String search() {
        if (searchUsername != null && !searchUsername.trim().isEmpty()) {
            searchResults = new ArrayList<>();
            for (User user : db.returnUsers() ) {
                if (user.getUsername().toLowerCase().contains(searchUsername.trim().toLowerCase())) {
                    searchResults.add(user);
                }
            }
        } else {
            searchResults = null;
        }
        return null;
    }

    public void allUsers() {
    	db.returnUsers();
    }

    public String show() {
    	searchResults = new ArrayList<>();
    	for (User reservation : db.returnUsers() ) {
    		searchResults.add(reservation);
	    }
    	return null;
    }

}
