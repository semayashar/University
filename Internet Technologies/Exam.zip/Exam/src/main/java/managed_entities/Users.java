package managed_entities;

import dao.Database;
import entities.User;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;

@Named
@RequestScoped
public class Users {

    @EJB
    Database db;

    private String username;
    private String email;
    private String password;
    private String message;

    // Getters and setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        if (username.length() >= 6 && username.matches(".*\\d.*")) {
            this.username = username;
        } else {
            message = "Username must be at least 6 characters long and contain at least one digit.";
        }
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email.length() >= 6 && email.contains("@") && email.contains(".")) {
            this.email = email;
        } else {
            message = "Email must be at least 6 characters long and contain an '@' and a '.'.";
        }
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        if (password.length() >= 6 && password.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).+$")) {
            this.password = password;
        } else {
            message = "Password must be at least 6 characters long and contain at least one uppercase letter, one lowercase letter, and one digit.";
        }
    }

    public String getMessage() {
        return message;
    }

    // Functions:
    public String register() {
        if (username == null || email == null || password == null) {
            message = "All fields must be filled.";
            return null;
        }

        if (db.found(username, password)) {
            message = "An account with this username and password already exists.";
            return null;
        }

        User user = new User(username, email, password);
        db.addUser(user);
        message = "Successfully registered.";
        return "registered";
    }

    public String login() {
        if (db.found(username, password)) {
            message = "Successfully logged in.";
            return "loggedin";
        } else {
            message = "Invalid username or password.";
            return null;
        }
    }
}
