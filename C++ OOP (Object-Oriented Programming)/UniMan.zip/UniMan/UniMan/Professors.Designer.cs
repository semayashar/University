﻿namespace UniMan
{
    partial class Professors
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Professors));
            label14 = new Label();
            prof_Experience = new TextBox();
            prof_Namet = new TextBox();
            label15 = new Label();
            prof_DOBdtp = new DateTimePicker();
            label16 = new Label();
            panel5 = new Panel();
            label19 = new Label();
            prof_Salary = new TextBox();
            label18 = new Label();
            label11 = new Label();
            prof_Qualcb = new ComboBox();
            label17 = new Label();
            prof_Addresstb = new RichTextBox();
            prof_DepIDcb = new ComboBox();
            prof_Delete = new Button();
            prof_Edit = new Button();
            prof_Save = new Button();
            panel3 = new Panel();
            prof_Gendercb = new ComboBox();
            label13 = new Label();
            label12 = new Label();
            label10 = new Label();
            prof_DepNametb = new TextBox();
            panel1 = new Panel();
            ProfDGV = new DataGridView();
            pictureBox9 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            label9 = new Label();
            colBtn = new Label();
            salaryBtn = new Label();
            feesBtn = new Label();
            courBtn = new Label();
            profBtn = new Label();
            studBtn = new Label();
            depBtn = new Label();
            homeBtn = new Label();
            panel4 = new Panel();
            label1 = new Label();
            pictureBox10 = new PictureBox();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ProfDGV).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            SuspendLayout();
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Julius Sans One", 9.75F);
            label14.Location = new Point(18, 125);
            label14.Name = "label14";
            label14.Size = new Size(58, 14);
            label14.TabIndex = 156;
            label14.Text = "Gender";
            // 
            // prof_Experience
            // 
            prof_Experience.Cursor = Cursors.Hand;
            prof_Experience.Location = new Point(475, 162);
            prof_Experience.Name = "prof_Experience";
            prof_Experience.Size = new Size(132, 23);
            prof_Experience.TabIndex = 127;
            // 
            // prof_Namet
            // 
            prof_Namet.Cursor = Cursors.Hand;
            prof_Namet.Location = new Point(157, 47);
            prof_Namet.Name = "prof_Namet";
            prof_Namet.Size = new Size(132, 23);
            prof_Namet.TabIndex = 124;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Julius Sans One", 9.75F);
            label15.Location = new Point(18, 91);
            label15.Name = "label15";
            label15.Size = new Size(103, 14);
            label15.TabIndex = 159;
            label15.Text = "Date of birth";
            // 
            // prof_DOBdtp
            // 
            prof_DOBdtp.Cursor = Cursors.Hand;
            prof_DOBdtp.Location = new Point(157, 84);
            prof_DOBdtp.Name = "prof_DOBdtp";
            prof_DOBdtp.Size = new Size(132, 23);
            prof_DOBdtp.TabIndex = 158;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Julius Sans One", 9.75F);
            label16.Location = new Point(336, 91);
            label16.Name = "label16";
            label16.Size = new Size(108, 14);
            label16.TabIndex = 161;
            label16.Text = "Department ID";
            // 
            // panel5
            // 
            panel5.BorderStyle = BorderStyle.FixedSingle;
            panel5.Controls.Add(label19);
            panel5.Controls.Add(prof_Salary);
            panel5.Controls.Add(label18);
            panel5.Controls.Add(label11);
            panel5.Controls.Add(prof_Qualcb);
            panel5.Controls.Add(label17);
            panel5.Controls.Add(prof_Addresstb);
            panel5.Controls.Add(label16);
            panel5.Controls.Add(prof_DepIDcb);
            panel5.Controls.Add(label15);
            panel5.Controls.Add(prof_DOBdtp);
            panel5.Controls.Add(label14);
            panel5.Controls.Add(prof_Delete);
            panel5.Controls.Add(prof_Edit);
            panel5.Controls.Add(prof_Save);
            panel5.Controls.Add(panel3);
            panel5.Controls.Add(prof_Gendercb);
            panel5.Controls.Add(label13);
            panel5.Controls.Add(label12);
            panel5.Controls.Add(label10);
            panel5.Controls.Add(prof_Experience);
            panel5.Controls.Add(prof_DepNametb);
            panel5.Controls.Add(prof_Namet);
            panel5.Location = new Point(224, 12);
            panel5.Name = "panel5";
            panel5.Size = new Size(629, 288);
            panel5.TabIndex = 188;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Julius Sans One", 9.75F);
            label19.Location = new Point(336, 202);
            label19.Name = "label19";
            label19.Size = new Size(51, 14);
            label19.TabIndex = 168;
            label19.Text = "Salary";
            // 
            // prof_Salary
            // 
            prof_Salary.Cursor = Cursors.Hand;
            prof_Salary.Location = new Point(475, 198);
            prof_Salary.Name = "prof_Salary";
            prof_Salary.Size = new Size(132, 23);
            prof_Salary.TabIndex = 167;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Julius Sans One", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label18.Location = new Point(262, 15);
            label18.Name = "label18";
            label18.Size = new Size(113, 18);
            label18.TabIndex = 166;
            label18.Text = "Professors";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Julius Sans One", 9.75F);
            label11.Location = new Point(336, 130);
            label11.Name = "label11";
            label11.Size = new Size(106, 14);
            label11.TabIndex = 165;
            label11.Text = "Qualification";
            // 
            // prof_Qualcb
            // 
            prof_Qualcb.Cursor = Cursors.Hand;
            prof_Qualcb.FormattingEnabled = true;
            prof_Qualcb.Items.AddRange(new object[] { "Bachelor's Degree", "Master's Degree", "Doctoral Degree (Doctorate)" });
            prof_Qualcb.Location = new Point(477, 123);
            prof_Qualcb.Name = "prof_Qualcb";
            prof_Qualcb.Size = new Size(132, 23);
            prof_Qualcb.TabIndex = 164;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Julius Sans One", 9.75F);
            label17.Location = new Point(18, 166);
            label17.Name = "label17";
            label17.Size = new Size(62, 14);
            label17.TabIndex = 163;
            label17.Text = "Address";
            // 
            // prof_Addresstb
            // 
            prof_Addresstb.Cursor = Cursors.Hand;
            prof_Addresstb.Location = new Point(157, 162);
            prof_Addresstb.Name = "prof_Addresstb";
            prof_Addresstb.Size = new Size(135, 51);
            prof_Addresstb.TabIndex = 162;
            prof_Addresstb.Text = "";
            // 
            // prof_DepIDcb
            // 
            prof_DepIDcb.Cursor = Cursors.Hand;
            prof_DepIDcb.FormattingEnabled = true;
            prof_DepIDcb.Location = new Point(477, 84);
            prof_DepIDcb.Name = "prof_DepIDcb";
            prof_DepIDcb.Size = new Size(132, 23);
            prof_DepIDcb.TabIndex = 160;
            prof_DepIDcb.SelectionChangeCommitted += prof_DepIDcb_SelectionChangeCommitted;
            // 
            // prof_Delete
            // 
            prof_Delete.Cursor = Cursors.Hand;
            prof_Delete.Location = new Point(425, 244);
            prof_Delete.Name = "prof_Delete";
            prof_Delete.Size = new Size(136, 31);
            prof_Delete.TabIndex = 155;
            prof_Delete.Text = "Delete";
            prof_Delete.UseVisualStyleBackColor = true;
            prof_Delete.Click += prof_Delete_Click;
            // 
            // prof_Edit
            // 
            prof_Edit.Cursor = Cursors.Hand;
            prof_Edit.Location = new Point(245, 244);
            prof_Edit.Name = "prof_Edit";
            prof_Edit.Size = new Size(136, 31);
            prof_Edit.TabIndex = 154;
            prof_Edit.Text = "Edit";
            prof_Edit.UseVisualStyleBackColor = true;
            prof_Edit.Click += prof_Edit_Click;
            // 
            // prof_Save
            // 
            prof_Save.Cursor = Cursors.Hand;
            prof_Save.Location = new Point(61, 244);
            prof_Save.Name = "prof_Save";
            prof_Save.Size = new Size(136, 31);
            prof_Save.TabIndex = 153;
            prof_Save.Text = "Save";
            prof_Save.UseVisualStyleBackColor = true;
            prof_Save.Click += prof_Save_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Brown;
            panel3.Location = new Point(310, 45);
            panel3.Name = "panel3";
            panel3.Size = new Size(5, 180);
            panel3.TabIndex = 133;
            // 
            // prof_Gendercb
            // 
            prof_Gendercb.Cursor = Cursors.Hand;
            prof_Gendercb.FormattingEnabled = true;
            prof_Gendercb.Items.AddRange(new object[] { "Male", "Female" });
            prof_Gendercb.Location = new Point(157, 121);
            prof_Gendercb.Name = "prof_Gendercb";
            prof_Gendercb.Size = new Size(132, 23);
            prof_Gendercb.TabIndex = 132;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Julius Sans One", 9.75F);
            label13.Location = new Point(336, 54);
            label13.Name = "label13";
            label13.Size = new Size(129, 14);
            label13.TabIndex = 131;
            label13.Text = "Department Name";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Julius Sans One", 9.75F);
            label12.Location = new Point(336, 166);
            label12.Name = "label12";
            label12.Size = new Size(77, 14);
            label12.TabIndex = 130;
            label12.Text = "Experience";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Julius Sans One", 9.75F);
            label10.Location = new Point(18, 54);
            label10.Name = "label10";
            label10.Size = new Size(119, 14);
            label10.TabIndex = 128;
            label10.Text = "Professor Name";
            // 
            // prof_DepNametb
            // 
            prof_DepNametb.Cursor = Cursors.Hand;
            prof_DepNametb.Location = new Point(477, 45);
            prof_DepNametb.Name = "prof_DepNametb";
            prof_DepNametb.Size = new Size(132, 23);
            prof_DepNametb.TabIndex = 126;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.GradientActiveCaption;
            panel1.Location = new Point(187, -9);
            panel1.Name = "panel1";
            panel1.Size = new Size(10, 548);
            panel1.TabIndex = 169;
            // 
            // ProfDGV
            // 
            ProfDGV.AllowUserToAddRows = false;
            ProfDGV.AllowUserToDeleteRows = false;
            ProfDGV.AllowUserToResizeColumns = false;
            ProfDGV.AllowUserToResizeRows = false;
            ProfDGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            ProfDGV.BackgroundColor = SystemColors.ButtonFace;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Julius Sans One", 9.75F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            ProfDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            ProfDGV.GridColor = SystemColors.ScrollBar;
            ProfDGV.Location = new Point(224, 306);
            ProfDGV.Name = "ProfDGV";
            ProfDGV.Size = new Size(629, 203);
            ProfDGV.TabIndex = 189;
            ProfDGV.CellContentClick += ProfDGV_CellContentClick;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(12, 479);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(30, 30);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 207;
            pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(12, 405);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(30, 30);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 206;
            pictureBox8.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(12, 170);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(30, 30);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 201;
            pictureBox3.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(12, 356);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(30, 30);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 205;
            pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(12, 309);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(30, 30);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 204;
            pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(12, 263);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(30, 30);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 203;
            pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(12, 218);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(30, 30);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 202;
            pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(12, 126);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(30, 30);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 200;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(12, 79);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(30, 30);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 199;
            pictureBox1.TabStop = false;
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label9.AutoSize = true;
            label9.Cursor = Cursors.Hand;
            label9.Font = new Font("Lucida Handwriting", 9.75F);
            label9.Location = new Point(60, 483);
            label9.Name = "label9";
            label9.Size = new Size(63, 17);
            label9.TabIndex = 198;
            label9.Text = "Log out";
            label9.Click += label9_Click;
            // 
            // colBtn
            // 
            colBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            colBtn.AutoSize = true;
            colBtn.Cursor = Cursors.Hand;
            colBtn.Font = new Font("Lucida Handwriting", 9.75F);
            colBtn.Location = new Point(56, 411);
            colBtn.Name = "colBtn";
            colBtn.Size = new Size(67, 17);
            colBtn.TabIndex = 197;
            colBtn.Text = "Colleges";
            colBtn.Click += colBtn_Click;
            // 
            // salaryBtn
            // 
            salaryBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            salaryBtn.AutoSize = true;
            salaryBtn.Cursor = Cursors.Hand;
            salaryBtn.Font = new Font("Lucida Handwriting", 9.75F);
            salaryBtn.Location = new Point(60, 361);
            salaryBtn.Name = "salaryBtn";
            salaryBtn.Size = new Size(54, 17);
            salaryBtn.TabIndex = 196;
            salaryBtn.Text = "Salary";
            salaryBtn.Click += salaryBtn_Click;
            // 
            // feesBtn
            // 
            feesBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            feesBtn.AutoSize = true;
            feesBtn.Cursor = Cursors.Hand;
            feesBtn.Font = new Font("Lucida Handwriting", 9.75F);
            feesBtn.Location = new Point(60, 316);
            feesBtn.Name = "feesBtn";
            feesBtn.Size = new Size(38, 17);
            feesBtn.TabIndex = 195;
            feesBtn.Text = "Fees";
            feesBtn.Click += feesBtn_Click;
            // 
            // courBtn
            // 
            courBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            courBtn.AutoSize = true;
            courBtn.Cursor = Cursors.Hand;
            courBtn.Font = new Font("Lucida Handwriting", 9.75F);
            courBtn.Location = new Point(60, 266);
            courBtn.Name = "courBtn";
            courBtn.Size = new Size(63, 17);
            courBtn.TabIndex = 194;
            courBtn.Text = "Courses";
            courBtn.Click += courBtn_Click;
            // 
            // profBtn
            // 
            profBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            profBtn.AutoSize = true;
            profBtn.Cursor = Cursors.Hand;
            profBtn.Font = new Font("Lucida Handwriting", 9.75F);
            profBtn.Location = new Point(60, 226);
            profBtn.Name = "profBtn";
            profBtn.Size = new Size(74, 17);
            profBtn.TabIndex = 193;
            profBtn.Text = "Professor";
            profBtn.Click += profBtn_Click;
            // 
            // studBtn
            // 
            studBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            studBtn.AutoSize = true;
            studBtn.Cursor = Cursors.Hand;
            studBtn.Font = new Font("Lucida Handwriting", 9.75F);
            studBtn.Location = new Point(60, 131);
            studBtn.Name = "studBtn";
            studBtn.Size = new Size(65, 17);
            studBtn.TabIndex = 192;
            studBtn.Text = "Student";
            studBtn.Click += studBtn_Click;
            // 
            // depBtn
            // 
            depBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            depBtn.AutoSize = true;
            depBtn.Cursor = Cursors.Hand;
            depBtn.Font = new Font("Lucida Handwriting", 9.75F);
            depBtn.Location = new Point(60, 176);
            depBtn.Name = "depBtn";
            depBtn.Size = new Size(96, 17);
            depBtn.TabIndex = 191;
            depBtn.Text = "Department";
            depBtn.Click += depBtn_Click;
            // 
            // homeBtn
            // 
            homeBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            homeBtn.AutoSize = true;
            homeBtn.Cursor = Cursors.Hand;
            homeBtn.Font = new Font("Lucida Handwriting", 9.75F);
            homeBtn.Location = new Point(60, 86);
            homeBtn.Name = "homeBtn";
            homeBtn.Size = new Size(50, 17);
            homeBtn.TabIndex = 190;
            homeBtn.Text = "Home";
            homeBtn.Click += homeBtn_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Brown;
            panel4.Location = new Point(72, 12);
            panel4.Name = "panel4";
            panel4.Size = new Size(3, 50);
            panel4.TabIndex = 209;
            // 
            // label1
            // 
            label1.Font = new Font("Julius Sans One", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(81, 9);
            label1.Margin = new Padding(0);
            label1.Name = "label1";
            label1.Size = new Size(100, 53);
            label1.TabIndex = 208;
            label1.Text = "University of Roseland";
            label1.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(12, 12);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(50, 50);
            pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 210;
            pictureBox10.TabStop = false;
            // 
            // Professors
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(869, 521);
            Controls.Add(panel4);
            Controls.Add(label1);
            Controls.Add(pictureBox10);
            Controls.Add(pictureBox9);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(label9);
            Controls.Add(colBtn);
            Controls.Add(salaryBtn);
            Controls.Add(feesBtn);
            Controls.Add(courBtn);
            Controls.Add(profBtn);
            Controls.Add(studBtn);
            Controls.Add(depBtn);
            Controls.Add(homeBtn);
            Controls.Add(ProfDGV);
            Controls.Add(panel5);
            Controls.Add(panel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Professors";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Professors";
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ProfDGV).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label14;
        private TextBox prof_Experience;
        private TextBox prof_Namet;
        private Label label15;
        private DateTimePicker prof_DOBdtp;
        private Label label16;
        private Panel panel5;
        private Label label19;
        private TextBox prof_Salary;
        private Label label18;
        private Label label11;
        private ComboBox prof_Qualcb;
        private Label label17;
        private RichTextBox prof_Addresstb;
        private ComboBox prof_DepIDcb;
        private Button prof_Delete;
        private Button prof_Edit;
        private Button prof_Save;
        private Panel panel3;
        private ComboBox prof_Gendercb;
        private Label label13;
        private Label label12;
        private Label label10;
        private TextBox prof_DepNametb;
        private Panel panel1;
        private DataGridView ProfDGV;
        private PictureBox pictureBox9;
        private PictureBox pictureBox8;
        private PictureBox pictureBox3;
        private PictureBox pictureBox7;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private Label label9;
        private Label colBtn;
        private Label salaryBtn;
        private Label feesBtn;
        private Label courBtn;
        private Label profBtn;
        private Label studBtn;
        private Label depBtn;
        private Label homeBtn;
        private Panel panel4;
        private Label label1;
        private PictureBox pictureBox10;
    }
}