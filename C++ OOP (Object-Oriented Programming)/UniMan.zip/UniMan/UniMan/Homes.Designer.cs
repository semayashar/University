﻿namespace UniMan
{
    partial class Homes
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Homes));
            panel1 = new Panel();
            panel2 = new Panel();
            label19 = new Label();
            home_FacCount = new Label();
            home_ColCount = new Label();
            home_DepCount = new Label();
            home_StudCount = new Label();
            pictureBox13 = new PictureBox();
            label13 = new Label();
            pictureBox12 = new PictureBox();
            label12 = new Label();
            pictureBox11 = new PictureBox();
            pictureBox10 = new PictureBox();
            label11 = new Label();
            label10 = new Label();
            panel3 = new Panel();
            panel5 = new Panel();
            label20 = new Label();
            label18 = new Label();
            panel4 = new Panel();
            panel6 = new Panel();
            label21 = new Label();
            pictureBox14 = new PictureBox();
            panel7 = new Panel();
            home_SalariesInDepo = new Label();
            pictureBox15 = new PictureBox();
            label22 = new Label();
            panel8 = new Panel();
            home_FinancesInDepo = new Label();
            pictureBox16 = new PictureBox();
            label23 = new Label();
            pictureBox9 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            label9 = new Label();
            colBtn = new Label();
            salaryBtn = new Label();
            feesBtn = new Label();
            courBtn = new Label();
            profBtn = new Label();
            studBtn = new Label();
            depBtn = new Label();
            homeBtn = new Label();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).BeginInit();
            panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.GradientActiveCaption;
            panel1.Location = new Point(184, -8);
            panel1.Name = "panel1";
            panel1.Size = new Size(10, 495);
            panel1.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.GradientInactiveCaption;
            panel2.Controls.Add(label19);
            panel2.Controls.Add(home_FacCount);
            panel2.Controls.Add(home_ColCount);
            panel2.Controls.Add(home_DepCount);
            panel2.Controls.Add(home_StudCount);
            panel2.Controls.Add(pictureBox13);
            panel2.Controls.Add(label13);
            panel2.Controls.Add(pictureBox12);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(pictureBox11);
            panel2.Controls.Add(pictureBox10);
            panel2.Controls.Add(label11);
            panel2.Controls.Add(label10);
            panel2.Location = new Point(679, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(177, 454);
            panel2.TabIndex = 19;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Julius Sans One", 12F, FontStyle.Bold);
            label19.Location = new Point(40, 24);
            label19.Name = "label19";
            label19.Size = new Size(98, 18);
            label19.TabIndex = 30;
            label19.Text = "Statistics";
            // 
            // home_FacCount
            // 
            home_FacCount.AutoSize = true;
            home_FacCount.Font = new Font("Dubai Medium", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            home_FacCount.Location = new Point(69, 382);
            home_FacCount.Name = "home_FacCount";
            home_FacCount.Size = new Size(39, 22);
            home_FacCount.TabIndex = 29;
            home_FacCount.Text = "Num";
            // 
            // home_ColCount
            // 
            home_ColCount.AutoSize = true;
            home_ColCount.Font = new Font("Dubai Medium", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            home_ColCount.Location = new Point(66, 284);
            home_ColCount.Name = "home_ColCount";
            home_ColCount.Size = new Size(39, 22);
            home_ColCount.TabIndex = 28;
            home_ColCount.Text = "Num";
            // 
            // home_DepCount
            // 
            home_DepCount.AutoSize = true;
            home_DepCount.Font = new Font("Dubai Medium", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            home_DepCount.Location = new Point(66, 191);
            home_DepCount.Name = "home_DepCount";
            home_DepCount.Size = new Size(39, 22);
            home_DepCount.TabIndex = 27;
            home_DepCount.Text = "Num";
            // 
            // home_StudCount
            // 
            home_StudCount.AutoSize = true;
            home_StudCount.Font = new Font("Dubai Medium", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            home_StudCount.Location = new Point(69, 100);
            home_StudCount.Name = "home_StudCount";
            home_StudCount.Size = new Size(39, 22);
            home_StudCount.TabIndex = 26;
            home_StudCount.Text = "Num";
            // 
            // pictureBox13
            // 
            pictureBox13.Image = (Image)resources.GetObject("pictureBox13.Image");
            pictureBox13.Location = new Point(16, 355);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(30, 30);
            pictureBox13.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox13.TabIndex = 25;
            pictureBox13.TabStop = false;
            // 
            // label13
            // 
            label13.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label13.AutoSize = true;
            label13.Font = new Font("Lucida Handwriting", 9.75F);
            label13.Location = new Point(64, 355);
            label13.Name = "label13";
            label13.Size = new Size(74, 17);
            label13.TabIndex = 24;
            label13.Text = "Faculties";
            // 
            // pictureBox12
            // 
            pictureBox12.Image = (Image)resources.GetObject("pictureBox12.Image");
            pictureBox12.Location = new Point(16, 257);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(30, 30);
            pictureBox12.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox12.TabIndex = 23;
            pictureBox12.TabStop = false;
            // 
            // label12
            // 
            label12.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label12.AutoSize = true;
            label12.Font = new Font("Lucida Handwriting", 9.75F);
            label12.Location = new Point(64, 257);
            label12.Name = "label12";
            label12.Size = new Size(67, 17);
            label12.TabIndex = 22;
            label12.Text = "Colleges";
            // 
            // pictureBox11
            // 
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(16, 164);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(30, 30);
            pictureBox11.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox11.TabIndex = 21;
            pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(16, 78);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(30, 30);
            pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 21;
            pictureBox10.TabStop = false;
            // 
            // label11
            // 
            label11.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label11.AutoSize = true;
            label11.Font = new Font("Lucida Handwriting", 9.75F);
            label11.Location = new Point(64, 164);
            label11.Name = "label11";
            label11.Size = new Size(102, 17);
            label11.TabIndex = 20;
            label11.Text = "Departments";
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label10.AutoSize = true;
            label10.Font = new Font("Lucida Handwriting", 9.75F);
            label10.Location = new Point(64, 76);
            label10.Name = "label10";
            label10.Size = new Size(71, 17);
            label10.TabIndex = 20;
            label10.Text = "Students";
            // 
            // panel3
            // 
            panel3.BorderStyle = BorderStyle.FixedSingle;
            panel3.Controls.Add(panel5);
            panel3.Controls.Add(label20);
            panel3.Controls.Add(label18);
            panel3.Location = new Point(215, 112);
            panel3.Name = "panel3";
            panel3.Size = new Size(442, 226);
            panel3.TabIndex = 20;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Brown;
            panel5.Location = new Point(35, 47);
            panel5.Name = "panel5";
            panel5.Size = new Size(379, 10);
            panel5.TabIndex = 2;
            // 
            // label20
            // 
            label20.Font = new Font("Julius Sans One", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label20.Location = new Point(26, 60);
            label20.Name = "label20";
            label20.Size = new Size(398, 152);
            label20.TabIndex = 1;
            label20.Text = "Discover excellence in education and community. Explore limitless opportunities for growth and innovation. Join us in shaping a brighter future together. ";
            label20.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Julius Sans One", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label18.Location = new Point(46, 26);
            label18.Name = "label18";
            label18.Size = new Size(357, 18);
            label18.TabIndex = 0;
            label18.Text = "Welcome to University of Roseland";
            // 
            // panel4
            // 
            panel4.Controls.Add(panel6);
            panel4.Controls.Add(label21);
            panel4.Controls.Add(pictureBox14);
            panel4.Location = new Point(215, 12);
            panel4.Name = "panel4";
            panel4.Size = new Size(442, 86);
            panel4.TabIndex = 21;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Brown;
            panel6.Location = new Point(136, 54);
            panel6.Name = "panel6";
            panel6.Size = new Size(266, 10);
            panel6.TabIndex = 25;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Julius Sans One", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label21.Location = new Point(150, 33);
            label21.Name = "label21";
            label21.Size = new Size(235, 18);
            label21.TabIndex = 24;
            label21.Text = "University of Roseland";
            // 
            // pictureBox14
            // 
            pictureBox14.Image = (Image)resources.GetObject("pictureBox14.Image");
            pictureBox14.Location = new Point(46, 7);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(79, 69);
            pictureBox14.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox14.TabIndex = 23;
            pictureBox14.TabStop = false;
            // 
            // panel7
            // 
            panel7.BorderStyle = BorderStyle.FixedSingle;
            panel7.Controls.Add(home_SalariesInDepo);
            panel7.Controls.Add(pictureBox15);
            panel7.Controls.Add(label22);
            panel7.Location = new Point(215, 358);
            panel7.Name = "panel7";
            panel7.Size = new Size(213, 99);
            panel7.TabIndex = 22;
            // 
            // home_SalariesInDepo
            // 
            home_SalariesInDepo.AutoSize = true;
            home_SalariesInDepo.Font = new Font("Dubai Medium", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            home_SalariesInDepo.Location = new Point(87, 38);
            home_SalariesInDepo.Name = "home_SalariesInDepo";
            home_SalariesInDepo.Size = new Size(39, 22);
            home_SalariesInDepo.TabIndex = 32;
            home_SalariesInDepo.Text = "Num";
            // 
            // pictureBox15
            // 
            pictureBox15.Image = (Image)resources.GetObject("pictureBox15.Image");
            pictureBox15.Location = new Point(14, 36);
            pictureBox15.Name = "pictureBox15";
            pictureBox15.Size = new Size(30, 30);
            pictureBox15.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox15.TabIndex = 24;
            pictureBox15.TabStop = false;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Julius Sans One", 12F, FontStyle.Bold);
            label22.Location = new Point(70, 8);
            label22.Name = "label22";
            label22.Size = new Size(84, 18);
            label22.TabIndex = 31;
            label22.Text = "Salaries";
            // 
            // panel8
            // 
            panel8.BorderStyle = BorderStyle.FixedSingle;
            panel8.Controls.Add(home_FinancesInDepo);
            panel8.Controls.Add(pictureBox16);
            panel8.Controls.Add(label23);
            panel8.Location = new Point(444, 358);
            panel8.Name = "panel8";
            panel8.Size = new Size(213, 99);
            panel8.TabIndex = 23;
            // 
            // home_FinancesInDepo
            // 
            home_FinancesInDepo.AutoSize = true;
            home_FinancesInDepo.Font = new Font("Dubai Medium", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            home_FinancesInDepo.Location = new Point(87, 38);
            home_FinancesInDepo.Name = "home_FinancesInDepo";
            home_FinancesInDepo.Size = new Size(39, 22);
            home_FinancesInDepo.TabIndex = 33;
            home_FinancesInDepo.Text = "Num";
            // 
            // pictureBox16
            // 
            pictureBox16.Image = (Image)resources.GetObject("pictureBox16.Image");
            pictureBox16.Location = new Point(14, 36);
            pictureBox16.Name = "pictureBox16";
            pictureBox16.Size = new Size(30, 30);
            pictureBox16.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox16.TabIndex = 24;
            pictureBox16.TabStop = false;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Julius Sans One", 12F, FontStyle.Bold);
            label23.Location = new Point(63, 8);
            label23.Name = "label23";
            label23.Size = new Size(93, 18);
            label23.TabIndex = 32;
            label23.Text = "Finances";
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(27, 429);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(30, 30);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 64;
            pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(27, 347);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(30, 30);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 63;
            pictureBox8.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(27, 112);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(30, 30);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 58;
            pictureBox3.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(27, 298);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(30, 30);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 62;
            pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(27, 251);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(30, 30);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 61;
            pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(27, 205);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(30, 30);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 60;
            pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(27, 160);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(30, 30);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 59;
            pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(27, 68);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(30, 30);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 57;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(27, 21);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(30, 30);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 56;
            pictureBox1.TabStop = false;
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label9.AutoSize = true;
            label9.Cursor = Cursors.Hand;
            label9.Font = new Font("Lucida Handwriting", 9.75F);
            label9.Location = new Point(75, 433);
            label9.Name = "label9";
            label9.Size = new Size(63, 17);
            label9.TabIndex = 55;
            label9.Text = "Log out";
            label9.Click += label9_Click;
            // 
            // colBtn
            // 
            colBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            colBtn.AutoSize = true;
            colBtn.Cursor = Cursors.Hand;
            colBtn.Font = new Font("Lucida Handwriting", 9.75F);
            colBtn.Location = new Point(71, 353);
            colBtn.Name = "colBtn";
            colBtn.Size = new Size(67, 17);
            colBtn.TabIndex = 54;
            colBtn.Text = "Colleges";
            colBtn.Click += colBtn_Click;
            // 
            // salaryBtn
            // 
            salaryBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            salaryBtn.AutoSize = true;
            salaryBtn.Cursor = Cursors.Hand;
            salaryBtn.Font = new Font("Lucida Handwriting", 9.75F);
            salaryBtn.Location = new Point(75, 303);
            salaryBtn.Name = "salaryBtn";
            salaryBtn.Size = new Size(54, 17);
            salaryBtn.TabIndex = 53;
            salaryBtn.Text = "Salary";
            salaryBtn.Click += salaryBtn_Click;
            // 
            // feesBtn
            // 
            feesBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            feesBtn.AutoSize = true;
            feesBtn.Cursor = Cursors.Hand;
            feesBtn.Font = new Font("Lucida Handwriting", 9.75F);
            feesBtn.Location = new Point(75, 258);
            feesBtn.Name = "feesBtn";
            feesBtn.Size = new Size(38, 17);
            feesBtn.TabIndex = 52;
            feesBtn.Text = "Fees";
            feesBtn.Click += feesBtn_Click;
            // 
            // courBtn
            // 
            courBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            courBtn.AutoSize = true;
            courBtn.Cursor = Cursors.Hand;
            courBtn.Font = new Font("Lucida Handwriting", 9.75F);
            courBtn.Location = new Point(75, 208);
            courBtn.Name = "courBtn";
            courBtn.Size = new Size(63, 17);
            courBtn.TabIndex = 51;
            courBtn.Text = "Courses";
            courBtn.Click += courBtn_Click;
            // 
            // profBtn
            // 
            profBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            profBtn.AutoSize = true;
            profBtn.Cursor = Cursors.Hand;
            profBtn.Font = new Font("Lucida Handwriting", 9.75F);
            profBtn.Location = new Point(75, 168);
            profBtn.Name = "profBtn";
            profBtn.Size = new Size(74, 17);
            profBtn.TabIndex = 50;
            profBtn.Text = "Professor";
            profBtn.Click += profBtn_Click;
            // 
            // studBtn
            // 
            studBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            studBtn.AutoSize = true;
            studBtn.Cursor = Cursors.Hand;
            studBtn.Font = new Font("Lucida Handwriting", 9.75F);
            studBtn.Location = new Point(75, 73);
            studBtn.Name = "studBtn";
            studBtn.Size = new Size(65, 17);
            studBtn.TabIndex = 49;
            studBtn.Text = "Student";
            studBtn.Click += studBtn_Click;
            // 
            // depBtn
            // 
            depBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            depBtn.AutoSize = true;
            depBtn.Cursor = Cursors.Hand;
            depBtn.Font = new Font("Lucida Handwriting", 9.75F);
            depBtn.Location = new Point(75, 118);
            depBtn.Name = "depBtn";
            depBtn.Size = new Size(96, 17);
            depBtn.TabIndex = 48;
            depBtn.Text = "Department";
            depBtn.Click += depBtn_Click;
            // 
            // homeBtn
            // 
            homeBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            homeBtn.AutoSize = true;
            homeBtn.Cursor = Cursors.Hand;
            homeBtn.Font = new Font("Lucida Handwriting", 9.75F);
            homeBtn.Location = new Point(75, 28);
            homeBtn.Name = "homeBtn";
            homeBtn.Size = new Size(50, 17);
            homeBtn.TabIndex = 47;
            homeBtn.Text = "Home";
            // 
            // Homes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(879, 476);
            Controls.Add(pictureBox9);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(label9);
            Controls.Add(colBtn);
            Controls.Add(salaryBtn);
            Controls.Add(feesBtn);
            Controls.Add(courBtn);
            Controls.Add(profBtn);
            Controls.Add(studBtn);
            Controls.Add(depBtn);
            Controls.Add(homeBtn);
            Controls.Add(panel8);
            Controls.Add(panel7);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Homes";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "University of Roseland";
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).EndInit();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private PictureBox pictureBox13;
        private Label label13;
        private PictureBox pictureBox12;
        private Label label12;
        private PictureBox pictureBox11;
        private PictureBox pictureBox10;
        private Label label11;
        private Label label10;
        private Label home_StudCount;
        private Label home_FacCount;
        private Label home_ColCount;
        private Label home_DepCount;
        private Panel panel3;
        private Label label18;
        private Label label19;
        private Label label20;
        private Panel panel5;
        private Panel panel4;
        private Label label21;
        private PictureBox pictureBox14;
        private Panel panel6;
        private Panel panel7;
        private Label home_SalariesInDepo;
        private PictureBox pictureBox15;
        private Label label22;
        private Panel panel8;
        private Label home_FinancesInDepo;
        private PictureBox pictureBox16;
        private Label label23;
        private PictureBox pictureBox9;
        private PictureBox pictureBox8;
        private PictureBox pictureBox3;
        private PictureBox pictureBox7;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private Label label9;
        private Label colBtn;
        private Label salaryBtn;
        private Label feesBtn;
        private Label courBtn;
        private Label profBtn;
        private Label studBtn;
        private Label depBtn;
        private Label homeBtn;
    }
}
