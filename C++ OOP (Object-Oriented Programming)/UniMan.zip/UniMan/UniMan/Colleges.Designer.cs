﻿namespace UniMan
{
    partial class Colleges
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Colleges));
            panel1 = new Panel();
            label14 = new Label();
            col_Delete = new Button();
            col_Edit = new Button();
            col_Save = new Button();
            panel5 = new Panel();
            label11 = new Label();
            col_PrincDOBdp = new DateTimePicker();
            panel3 = new Panel();
            label13 = new Label();
            label12 = new Label();
            label10 = new Label();
            col_Loctb = new TextBox();
            col_PrincNametb = new TextBox();
            col_Nametb = new TextBox();
            ColDGV = new DataGridView();
            pictureBox9 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            label9 = new Label();
            colBtn = new Label();
            salaryBtn = new Label();
            feesBtn = new Label();
            courBtn = new Label();
            profBtn = new Label();
            studBtn = new Label();
            depBtn = new Label();
            homeBtn = new Label();
            panel4 = new Panel();
            label1 = new Label();
            pictureBox10 = new PictureBox();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ColDGV).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.GradientActiveCaption;
            panel1.Location = new Point(182, -9);
            panel1.Name = "panel1";
            panel1.Size = new Size(10, 551);
            panel1.TabIndex = 147;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Julius Sans One", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.Location = new Point(263, 20);
            label14.Name = "label14";
            label14.Size = new Size(93, 18);
            label14.TabIndex = 26;
            label14.Text = "Colleges";
            // 
            // col_Delete
            // 
            col_Delete.Cursor = Cursors.Hand;
            col_Delete.Location = new Point(427, 187);
            col_Delete.Name = "col_Delete";
            col_Delete.Size = new Size(136, 31);
            col_Delete.TabIndex = 121;
            col_Delete.Text = "Delete";
            col_Delete.UseVisualStyleBackColor = true;
            col_Delete.Click += col_Delete_Click;
            // 
            // col_Edit
            // 
            col_Edit.Cursor = Cursors.Hand;
            col_Edit.Location = new Point(247, 187);
            col_Edit.Name = "col_Edit";
            col_Edit.Size = new Size(136, 31);
            col_Edit.TabIndex = 120;
            col_Edit.Text = "Edit";
            col_Edit.UseVisualStyleBackColor = true;
            col_Edit.Click += col_Edit_Click;
            // 
            // col_Save
            // 
            col_Save.Cursor = Cursors.Hand;
            col_Save.Location = new Point(63, 187);
            col_Save.Name = "col_Save";
            col_Save.Size = new Size(136, 31);
            col_Save.TabIndex = 119;
            col_Save.Text = "Save";
            col_Save.UseVisualStyleBackColor = true;
            col_Save.Click += col_Save_Click;
            // 
            // panel5
            // 
            panel5.BorderStyle = BorderStyle.FixedSingle;
            panel5.Controls.Add(label11);
            panel5.Controls.Add(col_PrincDOBdp);
            panel5.Controls.Add(label14);
            panel5.Controls.Add(col_Delete);
            panel5.Controls.Add(col_Edit);
            panel5.Controls.Add(col_Save);
            panel5.Controls.Add(panel3);
            panel5.Controls.Add(label13);
            panel5.Controls.Add(label12);
            panel5.Controls.Add(label10);
            panel5.Controls.Add(col_Loctb);
            panel5.Controls.Add(col_PrincNametb);
            panel5.Controls.Add(col_Nametb);
            panel5.Location = new Point(210, 12);
            panel5.Name = "panel5";
            panel5.Size = new Size(639, 237);
            panel5.TabIndex = 166;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Julius Sans One", 9.75F);
            label11.Location = new Point(319, 122);
            label11.Name = "label11";
            label11.Size = new Size(37, 14);
            label11.TabIndex = 123;
            label11.Text = "DOB";
            label11.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // col_PrincDOBdp
            // 
            col_PrincDOBdp.Cursor = Cursors.Hand;
            col_PrincDOBdp.Location = new Point(424, 119);
            col_PrincDOBdp.Name = "col_PrincDOBdp";
            col_PrincDOBdp.Size = new Size(139, 23);
            col_PrincDOBdp.TabIndex = 122;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Brown;
            panel3.Location = new Point(308, 62);
            panel3.Name = "panel3";
            panel3.Size = new Size(5, 100);
            panel3.TabIndex = 99;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Julius Sans One", 9.75F);
            label13.Location = new Point(22, 124);
            label13.Name = "label13";
            label13.Size = new Size(112, 14);
            label13.TabIndex = 97;
            label13.Text = "Principal Name";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Julius Sans One", 9.75F);
            label12.Location = new Point(319, 84);
            label12.Name = "label12";
            label12.Size = new Size(74, 14);
            label12.TabIndex = 96;
            label12.Text = "Location";
            label12.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Julius Sans One", 9.75F);
            label10.Location = new Point(22, 88);
            label10.Name = "label10";
            label10.Size = new Size(103, 14);
            label10.TabIndex = 94;
            label10.Text = "College Name";
            // 
            // col_Loctb
            // 
            col_Loctb.Cursor = Cursors.Hand;
            col_Loctb.Location = new Point(424, 81);
            col_Loctb.Name = "col_Loctb";
            col_Loctb.Size = new Size(139, 23);
            col_Loctb.TabIndex = 93;
            // 
            // col_PrincNametb
            // 
            col_PrincNametb.Cursor = Cursors.Hand;
            col_PrincNametb.Location = new Point(157, 120);
            col_PrincNametb.Name = "col_PrincNametb";
            col_PrincNametb.Size = new Size(133, 23);
            col_PrincNametb.TabIndex = 92;
            // 
            // col_Nametb
            // 
            col_Nametb.Cursor = Cursors.Hand;
            col_Nametb.Location = new Point(157, 81);
            col_Nametb.Name = "col_Nametb";
            col_Nametb.Size = new Size(132, 23);
            col_Nametb.TabIndex = 90;
            // 
            // ColDGV
            // 
            ColDGV.AllowUserToAddRows = false;
            ColDGV.AllowUserToDeleteRows = false;
            ColDGV.AllowUserToResizeColumns = false;
            ColDGV.AllowUserToResizeRows = false;
            ColDGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            ColDGV.BackgroundColor = SystemColors.ButtonFace;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Julius Sans One", 9.75F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            ColDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            ColDGV.GridColor = SystemColors.ScrollBar;
            ColDGV.Location = new Point(210, 255);
            ColDGV.Name = "ColDGV";
            ColDGV.Size = new Size(639, 254);
            ColDGV.TabIndex = 168;
            ColDGV.CellContentClick += ColDGV_CellContentClick;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(12, 479);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(30, 30);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 203;
            pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(12, 407);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(30, 30);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 202;
            pictureBox8.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(12, 172);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(30, 30);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 197;
            pictureBox3.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(12, 358);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(30, 30);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 201;
            pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(12, 311);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(30, 30);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 200;
            pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(12, 265);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(30, 30);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 199;
            pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(12, 220);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(30, 30);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 198;
            pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(12, 128);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(30, 30);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 196;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(12, 81);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(30, 30);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 195;
            pictureBox1.TabStop = false;
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label9.AutoSize = true;
            label9.Cursor = Cursors.Hand;
            label9.Font = new Font("Lucida Handwriting", 9.75F);
            label9.Location = new Point(60, 483);
            label9.Name = "label9";
            label9.Size = new Size(63, 17);
            label9.TabIndex = 194;
            label9.Text = "Log out";
            label9.Click += label9_Click;
            // 
            // colBtn
            // 
            colBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            colBtn.AutoSize = true;
            colBtn.Cursor = Cursors.Hand;
            colBtn.Font = new Font("Lucida Handwriting", 9.75F);
            colBtn.Location = new Point(56, 413);
            colBtn.Name = "colBtn";
            colBtn.Size = new Size(67, 17);
            colBtn.TabIndex = 193;
            colBtn.Text = "Colleges";
            colBtn.Click += colBtn_Click;
            // 
            // salaryBtn
            // 
            salaryBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            salaryBtn.AutoSize = true;
            salaryBtn.Cursor = Cursors.Hand;
            salaryBtn.Font = new Font("Lucida Handwriting", 9.75F);
            salaryBtn.Location = new Point(60, 363);
            salaryBtn.Name = "salaryBtn";
            salaryBtn.Size = new Size(54, 17);
            salaryBtn.TabIndex = 192;
            salaryBtn.Text = "Salary";
            salaryBtn.Click += salaryBtn_Click;
            // 
            // feesBtn
            // 
            feesBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            feesBtn.AutoSize = true;
            feesBtn.Cursor = Cursors.Hand;
            feesBtn.Font = new Font("Lucida Handwriting", 9.75F);
            feesBtn.Location = new Point(60, 318);
            feesBtn.Name = "feesBtn";
            feesBtn.Size = new Size(38, 17);
            feesBtn.TabIndex = 191;
            feesBtn.Text = "Fees";
            feesBtn.Click += feesBtn_Click;
            // 
            // courBtn
            // 
            courBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            courBtn.AutoSize = true;
            courBtn.Cursor = Cursors.Hand;
            courBtn.Font = new Font("Lucida Handwriting", 9.75F);
            courBtn.Location = new Point(60, 268);
            courBtn.Name = "courBtn";
            courBtn.Size = new Size(63, 17);
            courBtn.TabIndex = 190;
            courBtn.Text = "Courses";
            courBtn.Click += courBtn_Click;
            // 
            // profBtn
            // 
            profBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            profBtn.AutoSize = true;
            profBtn.Cursor = Cursors.Hand;
            profBtn.Font = new Font("Lucida Handwriting", 9.75F);
            profBtn.Location = new Point(60, 228);
            profBtn.Name = "profBtn";
            profBtn.Size = new Size(74, 17);
            profBtn.TabIndex = 189;
            profBtn.Text = "Professor";
            profBtn.Click += profBtn_Click;
            // 
            // studBtn
            // 
            studBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            studBtn.AutoSize = true;
            studBtn.Cursor = Cursors.Hand;
            studBtn.Font = new Font("Lucida Handwriting", 9.75F);
            studBtn.Location = new Point(60, 133);
            studBtn.Name = "studBtn";
            studBtn.Size = new Size(65, 17);
            studBtn.TabIndex = 188;
            studBtn.Text = "Student";
            studBtn.Click += studBtn_Click;
            // 
            // depBtn
            // 
            depBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            depBtn.AutoSize = true;
            depBtn.Cursor = Cursors.Hand;
            depBtn.Font = new Font("Lucida Handwriting", 9.75F);
            depBtn.Location = new Point(60, 178);
            depBtn.Name = "depBtn";
            depBtn.Size = new Size(96, 17);
            depBtn.TabIndex = 187;
            depBtn.Text = "Department";
            depBtn.Click += depBtn_Click;
            // 
            // homeBtn
            // 
            homeBtn.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            homeBtn.AutoSize = true;
            homeBtn.Cursor = Cursors.Hand;
            homeBtn.Font = new Font("Lucida Handwriting", 9.75F);
            homeBtn.Location = new Point(60, 88);
            homeBtn.Name = "homeBtn";
            homeBtn.Size = new Size(50, 17);
            homeBtn.TabIndex = 186;
            homeBtn.Text = "Home";
            homeBtn.Click += homeBtn_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Brown;
            panel4.Location = new Point(72, 12);
            panel4.Name = "panel4";
            panel4.Size = new Size(3, 50);
            panel4.TabIndex = 218;
            // 
            // label1
            // 
            label1.Font = new Font("Julius Sans One", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(81, 9);
            label1.Margin = new Padding(0);
            label1.Name = "label1";
            label1.Size = new Size(100, 53);
            label1.TabIndex = 217;
            label1.Text = "University of Roseland";
            label1.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(12, 12);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(50, 50);
            pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 219;
            pictureBox10.TabStop = false;
            // 
            // Colleges
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(869, 521);
            Controls.Add(panel4);
            Controls.Add(label1);
            Controls.Add(pictureBox10);
            Controls.Add(pictureBox9);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(label9);
            Controls.Add(colBtn);
            Controls.Add(salaryBtn);
            Controls.Add(feesBtn);
            Controls.Add(courBtn);
            Controls.Add(profBtn);
            Controls.Add(studBtn);
            Controls.Add(depBtn);
            Controls.Add(homeBtn);
            Controls.Add(ColDGV);
            Controls.Add(panel1);
            Controls.Add(panel5);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Colleges";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Colleges";
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ColDGV).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel panel1;
        private Label label14;
        private Button col_Delete;
        private Button col_Edit;
        private Button col_Save;
        private Panel panel5;
        private Panel panel3;
        private Label label13;
        private Label label12;
        private Label label10;
        private TextBox col_Loctb;
        private TextBox col_PrincNametb;
        private TextBox col_Nametb;
        private Label label11;
        private DateTimePicker col_PrincDOBdp;
        private DataGridView ColDGV;
        private PictureBox pictureBox9;
        private PictureBox pictureBox8;
        private PictureBox pictureBox3;
        private PictureBox pictureBox7;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private Label label9;
        private Label colBtn;
        private Label salaryBtn;
        private Label feesBtn;
        private Label courBtn;
        private Label profBtn;
        private Label studBtn;
        private Label depBtn;
        private Label homeBtn;
        private Panel panel4;
        private Label label1;
        private PictureBox pictureBox10;
    }
}